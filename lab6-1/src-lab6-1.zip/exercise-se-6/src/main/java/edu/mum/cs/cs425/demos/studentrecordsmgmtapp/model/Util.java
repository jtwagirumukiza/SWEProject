package edu.mum.cs.cs425.demos.studentrecordsmgmtapp.model;

import java.time.format.DateTimeFormatter;

public class Util {
    private static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");

    public static DateTimeFormatter getDateTimeFormatter() {
        return dtf;

    }
}
