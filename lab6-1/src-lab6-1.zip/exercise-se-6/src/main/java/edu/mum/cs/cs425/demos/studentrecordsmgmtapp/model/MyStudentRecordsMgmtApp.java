package edu.mum.cs.cs425.demos.studentrecordsmgmtapp.model;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MyStudentRecordsMgmtApp {
    public static void main(String[] args) throws ParseException {

        Student[] students = new Student[]{
                new Student(110001, "Dave", LocalDate.parse("11/18/1951", Util.getDateTimeFormatter()))
                , new Student(110002, "Anna", LocalDate.parse("12/07/1990", Util.getDateTimeFormatter()))
                , new Student(110003, "Erica", LocalDate.parse("01/31/1974", Util.getDateTimeFormatter()))
                , new Student(110004, "Carlos", LocalDate.parse("08/22/2009", Util.getDateTimeFormatter()))
                , new Student(110005, "Bob", LocalDate.parse("03/05/1990", Util.getDateTimeFormatter()))
        };

        printListOfStudents(students);
        printListOfPlatinumAlumniStudents(students);
        printHelloWorldBasedOnArray(new int[]{21, 35, 54, 7, 5,});
        printSecondSmallest(new int[]{1, 2, 3, 4, 5});
        printSecondSmallest(new int[]{19,9,11,0,12});

    }

    private static void printSecondSmallest(int[] numbers) {
        if (numbers.length < 2) return;
        System.out.println();
        System.out.println();
        System.out.println("Original array: " + Arrays.toString(numbers));
        for (int i = 0; i < numbers.length; i++) {
            for (int j = i + 1; i <= 2 && j < numbers.length; j++) {
                if (numbers[i] < numbers[j]) {
                    swap(numbers, i, j);
                }
            }
        }

        System.out.println("Second biggest: " + numbers[1]);
    }

    private static void swap(int[] numbers, int i, int j) {
        int temp = numbers[i];
        numbers[i] = numbers[j];
        numbers[j] = temp;
    }


    private static void printHelloWorldBasedOnArray(int[] numbers) {
        System.out.println("HelloWorld printer");
        for (int n : numbers) {
            if (n % 5 == 0) {
                System.out.print("Hello");
            }
            if (n % 7 == 0) {
                System.out.println("World");
            }
        }
    }

    private static void printListOfPlatinumAlumniStudents(Student[] students) {
        List<Student> platinumStudents = getListOfPlatinumAlumniStudents(students);
        System.out.println("Platinum students");
        platinumStudents.forEach(System.out::println);
        System.out.println("");
    }

    private static List<Student> getListOfPlatinumAlumniStudents(Student[] students) {
        LocalDate todayLocalDate = LocalDate.now();
        return Stream.of(students).filter(student -> Period.between(student.getDateOfAdmission(), todayLocalDate).getYears() >= 30).collect(Collectors.toList());

    }

    private static void printListOfStudents(Student[] students) {
        Set<Student> sortedStudents = new TreeSet<>();
        Collections.addAll(sortedStudents, students);

        System.out.println("Sorted students");
        sortedStudents.forEach(System.out::println);
        System.out.println("");
    }
}
